﻿Public Class Form1
    Dim Message1 As String = "This is a Message"
    Dim Message2 As Integer = 1101
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MessageBox.Show(Message1)
    End Sub
End Class
